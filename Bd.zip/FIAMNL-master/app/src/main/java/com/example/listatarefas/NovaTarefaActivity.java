package com.example.listatarefas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NovaTarefaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__tarefas);
    }
}
